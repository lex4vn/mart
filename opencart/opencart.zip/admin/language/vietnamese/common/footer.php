<?php
// Text
$_['text_footer'] = 'Quản trị website TMĐT';
$_['text_version'] 	= '<b>Phiên bản %s</b>';
?>